# Metallica Tribute Page

A Pen created on CodePen.io. Original URL: [https://codepen.io/vanessaboettcher/pen/NWzajgN](https://codepen.io/vanessaboettcher/pen/NWzajgN).

